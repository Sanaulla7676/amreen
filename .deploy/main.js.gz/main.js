(function(){var d=document.documentElement;
if(!window.gsap||matchMedia("(prefers-reduced-motion:reduce)").matches){d.classList.remove("js");return}
gsap.registerPlugin(ScrollTrigger);
var cur=document.querySelector(".curtain");
gsap.fromTo(cur,{scaleY:1,transformOrigin:"top"},{scaleY:0,duration:.8,ease:"power3.inOut"});
document.addEventListener("click",function(e){var a=e.target.closest("a[href]");
 if(!a||a.target||/^(https?:|tel:|mailto:|#)/.test(a.getAttribute("href")))return;
 e.preventDefault();gsap.fromTo(cur,{scaleY:0,transformOrigin:"bottom"},{scaleY:1,duration:.55,ease:"power3.in",onComplete:function(){location.href=a.href}})});
addEventListener("pageshow",function(e){if(e.persisted)gsap.set(cur,{scaleY:0})});
gsap.to(".bar",{scaleX:1,ease:"none",scrollTrigger:{scrub:.3,start:0,end:"max"}});
var h=document.querySelector(".hero h1");
if(h){var t=h.textContent;h.setAttribute("aria-label",t);h.innerHTML=t.split(" ").map(function(w){return'<span class="w" aria-hidden="true">'+w.split("").map(function(c){return'<span class="c">'+c+"</span>"}).join("")+"</span>"}).join(" ");
 gsap.timeline({defaults:{ease:"expo.out"}}).from(".hero .kick",{y:20,opacity:0,duration:.6,delay:.5})
 .from(".hero h1 .c",{yPercent:110,rotateX:-60,opacity:0,duration:.9,stagger:.025},"<.1")
 .from(".hero .lead,.hero .btn,.hero .chips li",{y:24,opacity:0,duration:.7,stagger:.08},"-=.5")}
gsap.to(".b1",{y:40,x:-30,repeat:-1,yoyo:true,duration:5,ease:"sine.inOut"});gsap.to(".b2",{y:-40,x:30,repeat:-1,yoyo:true,duration:6,ease:"sine.inOut"});
gsap.to(".hero .blob",{yPercent:30,ease:"none",scrollTrigger:{trigger:".hero",scrub:true,start:"top top",end:"bottom top"}});
ScrollTrigger.batch("[data-r]",{start:"top 88%",once:true,onEnter:function(b){gsap.fromTo(b,{y:36,opacity:0},{y:0,opacity:1,duration:.8,stagger:.1,ease:"power3.out"})}});
document.querySelectorAll("[data-count]").forEach(function(el){var n=+el.dataset.count,o={v:0},s=el.dataset.suf||"",f=n%1?1:0;
 ScrollTrigger.create({trigger:el,start:"top 90%",once:true,onEnter:function(){gsap.to(o,{v:n,duration:1.8,ease:"power2.out",onUpdate:function(){el.textContent=o.v.toFixed(f)+s}})}})});
gsap.from("tbody tr",{opacity:0,x:-24,stagger:.07,duration:.55,ease:"power2.out",scrollTrigger:{trigger:"table",start:"top 85%",once:true}});
if(document.querySelector(".steps"))gsap.fromTo(".line",{scaleY:0},{scaleY:1,ease:"none",scrollTrigger:{trigger:".steps",start:"top 70%",end:"bottom 70%",scrub:true}});
var m=document.querySelector(".mq div");if(m){m.parentNode.appendChild(m.cloneNode(true));gsap.to(".mq div",{xPercent:-100,duration:28,ease:"none",repeat:-1})}
document.querySelectorAll(".btn").forEach(function(b){var x=gsap.quickTo(b,"x",{duration:.4,ease:"power3"}),y=gsap.quickTo(b,"y",{duration:.4,ease:"power3"});
 b.addEventListener("mousemove",function(e){var r=b.getBoundingClientRect();x((e.clientX-r.left-r.width/2)*.25);y((e.clientY-r.top-r.height/2)*.25)});
 b.addEventListener("mouseleave",function(){x(0);y(0)})});
document.querySelectorAll("details").forEach(function(el){el.addEventListener("toggle",function(){if(el.open)gsap.from(el.querySelector("p"),{height:0,opacity:0,duration:.4,ease:"power2.out"})})});
})();
document.querySelectorAll("form[data-wa]").forEach(function(f){f.addEventListener("submit",function(e){e.preventDefault();var v=new FormData(f);
 open("https://wa.me/919876543210?text="+encodeURIComponent("Hi Amreen Studio, I'm "+v.get("name")+". Enquiry: "+v.get("topic")+" on "+(v.get("date")||"date to be confirmed")),"_blank","noopener")})});
